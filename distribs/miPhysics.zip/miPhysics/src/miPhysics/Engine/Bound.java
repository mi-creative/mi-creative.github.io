package miPhysics.Engine;

public enum Bound {
    X_LEFT,
    X_RIGHT,
    Y_LEFT,
    Y_RIGHT,
    Z_LEFT,
    Z_RIGHT,
    FIXED_CORNERS,
    FIXED_CENTRE
}

package miPhysics.Engine.Sound;

public enum listenerAxis {
    X,
    Y,
    Z,
    ALL,
}

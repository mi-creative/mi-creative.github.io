package miPhysics.Engine;

public enum filterType {
    NONE,
    HIGH_PASS
}

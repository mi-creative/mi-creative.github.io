package miPhysics.Engine;


public enum inOutType {
    OBSERVER3D,
    DRIVER3D,
    UNDEFINED
}

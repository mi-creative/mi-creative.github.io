package miPhysics.Engine;


public enum interType {
  SPRING3D,
  DAMPER3D,
  SPRINGDAMPER3D,
  SPRINGDAMPER1D,
  ROPE3D,
  CONTACT3D,
  PLANECONTACT3D,
  BUBBLE3D,
  ATTRACTOR3D,
  UNDEFINED
}

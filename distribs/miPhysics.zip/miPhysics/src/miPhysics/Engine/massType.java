package miPhysics.Engine;


public enum massType {
  MASS3D,
  MASS1D,
  MASS2DPLANE,
  GROUND3D,
  GROUND1D,
  OSC3D,
  OSC1D,
  HAPTICINPUT3D,
  POSINPUT3D,
  UNDEFINED
}
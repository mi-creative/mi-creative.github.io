package miPhysics.Engine;

/* may not be totally complete yet : add parameters as needed */

public enum param {
    MASS,
    RADIUS,
    STIFFNESS,
    DAMPING,
    DISTANCE,
    ATTRACTION
}

package miPhysics.Engine;

public enum paramSystem {
	ALGO_UNITS,
	REAL_UNITS
}

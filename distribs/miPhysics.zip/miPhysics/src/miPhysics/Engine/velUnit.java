 package miPhysics.Engine;

 public enum velUnit {
 	PER_SEC,
 	PER_SAMPLE
 }
